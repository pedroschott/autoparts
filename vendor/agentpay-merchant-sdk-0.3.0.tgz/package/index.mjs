var __defProp = Object.defineProperty;
var __defProps = Object.defineProperties;
var __getOwnPropDescs = Object.getOwnPropertyDescriptors;
var __getOwnPropSymbols = Object.getOwnPropertySymbols;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __propIsEnum = Object.prototype.propertyIsEnumerable;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __spreadValues = (a, b) => {
  for (var prop in b || (b = {}))
    if (__hasOwnProp.call(b, prop))
      __defNormalProp(a, prop, b[prop]);
  if (__getOwnPropSymbols)
    for (var prop of __getOwnPropSymbols(b)) {
      if (__propIsEnum.call(b, prop))
        __defNormalProp(a, prop, b[prop]);
    }
  return a;
};
var __spreadProps = (a, b) => __defProps(a, __getOwnPropDescs(b));

// sdk/index.ts
import { z } from "zod";

// lib/crypto.ts
import {
  createCipheriv,
  createDecipheriv,
  createHash,
  createPrivateKey,
  createPublicKey,
  generateKeyPairSync,
  randomBytes,
  sign,
  verify
} from "crypto";

// lib/canonical-json.ts
function sortValue(value) {
  if (Array.isArray(value)) {
    return value.map(sortValue);
  }
  if (value && typeof value === "object") {
    return Object.fromEntries(
      Object.entries(value).sort(([left], [right]) => left.localeCompare(right)).map(([key, nested]) => [key, sortValue(nested)])
    );
  }
  return value;
}
function canonicalJson(value) {
  return JSON.stringify(sortValue(value));
}

// lib/crypto.ts
function sha256Base64Url(input) {
  return createHash("sha256").update(input).digest("base64url");
}
function bodyHash(body) {
  return sha256Base64Url(body);
}
function agentSigningMessage(input) {
  return [
    input.method.toUpperCase(),
    input.path,
    bodyHash(input.body),
    input.timestamp,
    input.nonce
  ].join("|");
}
function generateEd25519KeyPair() {
  const { privateKey, publicKey } = generateKeyPairSync("ed25519");
  return {
    privateKey: privateKey.export({ type: "pkcs8", format: "pem" }).toString(),
    publicKey: publicKey.export({ type: "spki", format: "pem" }).toString()
  };
}
function signText(privateKeyPem, value) {
  return sign(null, Buffer.from(value), createPrivateKey(privateKeyPem)).toString("base64url");
}
function verifyText(publicKeyPem, value, signature) {
  try {
    return verify(
      null,
      Buffer.from(value),
      createPublicKey(publicKeyPem),
      Buffer.from(signature, "base64url")
    );
  } catch (e) {
    return false;
  }
}
function signCanonical(privateKeyPem, value) {
  return signText(privateKeyPem, canonicalJson(value));
}

// lib/agentpay-policy.ts
function evaluatePolicy(mandate, cart, now = /* @__PURE__ */ new Date()) {
  if (!mandate) {
    return { decision: "refused", reason_code: "MANDATE_NOT_FOUND" };
  }
  if (mandate.status === "revoked") {
    return { decision: "refused", reason_code: "MANDATE_REVOKED" };
  }
  if (mandate.status !== "active" || now < new Date(mandate.validity.not_before) || now > new Date(mandate.validity.expires_at)) {
    return { decision: "refused", reason_code: "MANDATE_EXPIRED" };
  }
  if (!mandate.scope.merchants.includes(cart.merchant_id)) {
    return { decision: "refused", reason_code: "MERCHANT_NOT_IN_SCOPE" };
  }
  if (!mandate.scope.categories.includes(cart.category)) {
    return { decision: "refused", reason_code: "CATEGORY_NOT_IN_SCOPE" };
  }
  if (cart.currency !== mandate.limits.currency) {
    return { decision: "refused", reason_code: "CURRENCY_MISMATCH" };
  }
  if (mandate.usage.approved_uses >= mandate.limits.max_uses) {
    return { decision: "refused", reason_code: "USES_EXCEEDED" };
  }
  if (mandate.usage.cumulative_cents + cart.amount_cents > mandate.limits.cumulative_cents) {
    return { decision: "refused", reason_code: "CUMULATIVE_EXCEEDED" };
  }
  if (cart.amount_cents > mandate.limits.per_purchase_cents && !cart.exception_id) {
    return { decision: "escalated", reason_code: "AMOUNT_EXCEEDS_LIMIT" };
  }
  return { decision: "approved", reason_code: null };
}

// sdk/index.ts
var manifestSchema = z.object({
  protocol: z.literal("agentpay/1.0"),
  merchant: z.object({ id: z.string().min(1), name: z.string().min(1) }),
  checkout_endpoint: z.url(),
  registry_url: z.url(),
  capabilities: z.array(z.string().min(1)).min(1),
  catalog_endpoint: z.url().optional(),
  categories: z.array(z.string().min(1)).optional(),
  currency: z.string().length(3).optional(),
  product_url_template: z.string().min(1).optional(),
  documentation_url: z.url().optional(),
  ships_to: z.array(z.string().length(2)).optional()
});
var catalogProductSchema = z.object({
  product_id: z.string().min(1),
  name: z.string().min(1),
  category: z.string().min(1),
  price_cents: z.number().int().positive(),
  currency: z.string().length(3),
  description: z.string().optional(),
  sku: z.string().optional(),
  brand: z.string().optional(),
  availability: z.enum(["in_stock", "out_of_stock"]).optional(),
  url: z.url().optional()
});
var catalogSchema = z.object({
  protocol: z.literal("agentpay-catalog/1.0"),
  merchant: z.object({ id: z.string().min(1), name: z.string().min(1) }),
  currency: z.string().length(3),
  categories: z.array(z.string().min(1)),
  query: z.object({
    q: z.string().nullable(),
    category: z.string().nullable(),
    product_id: z.string().nullable(),
    max_price_cents: z.number().int().nullable(),
    limit: z.number().int()
  }),
  total: z.number().int().nonnegative(),
  products: z.array(catalogProductSchema)
});
var shippingAddressSchema = z.object({
  recipient: z.string().trim().min(1).max(120),
  line1: z.string().trim().min(1).max(160),
  line2: z.string().trim().max(160).optional(),
  city: z.string().trim().min(1).max(100),
  region: z.string().trim().max(100).optional(),
  postal_code: z.string().trim().min(3).max(20),
  country_code: z.string().trim().length(2).transform((value) => value.toUpperCase()),
  phone: z.string().trim().max(32).optional(),
  instructions: z.string().trim().max(280).optional()
});
var checkoutBodySchema = z.object({
  mandate_id: z.uuid(),
  merchant_id: z.string().min(1),
  product_id: z.string().min(1),
  exception_id: z.uuid().optional(),
  /**
   * Where this order ships. Omitted means the buyer's registered address, which
   * AgentPay already holds; a store that needs the address to quote delivery
   * receives it here and never has to ask the agent for it in conversation.
   */
  shipping_address: shippingAddressSchema.optional(),
  shipping_address_source: z.enum(["registered", "custom"]).optional(),
  /** Why the agent is buying this, in the buyer's own terms. Recorded, never scored. */
  purchase_reason: z.string().trim().min(1).max(500).optional()
});
var DEFAULT_CATALOG_LIMIT = 10;
var MAX_CATALOG_LIMIT = 50;
function merchantManifest(input) {
  var _a, _b;
  const origin = new URL(input.origin).origin;
  const capabilities = ["intent-mandates", "live-revocation", "mock-payment"];
  if (input.catalogPath) capabilities.push("catalog-search");
  if (input.customShipping) capabilities.push("custom-shipping");
  return __spreadValues(__spreadValues(__spreadValues(__spreadValues(__spreadValues(__spreadValues({
    protocol: "agentpay/1.0",
    merchant: { id: input.merchantId, name: input.merchantName },
    checkout_endpoint: new URL((_a = input.checkoutPath) != null ? _a : "/api/store/checkout", origin).toString(),
    registry_url: input.registryUrl ? new URL(input.registryUrl).toString() : origin,
    capabilities
  }, input.catalogPath ? { catalog_endpoint: new URL(input.catalogPath, origin).toString() } : {}), input.categories ? { categories: uniqueSlugs(input.categories) } : {}), input.currency ? { currency: input.currency.toUpperCase() } : {}), ((_b = input.shipsTo) == null ? void 0 : _b.length) ? { ships_to: Array.from(new Set(input.shipsTo.map((code) => code.trim().toUpperCase()))).sort() } : {}), input.productUrlTemplate ? { product_url_template: `${origin}${input.productUrlTemplate.startsWith("/") ? "" : "/"}${input.productUrlTemplate}` } : {}), input.documentationUrl ? { documentation_url: new URL(input.documentationUrl).toString() } : {});
}
async function discoverAgentPayMerchant(merchantUrl, fetcher = fetch) {
  const candidate = new URL(merchantUrl);
  const manifestUrl = candidate.pathname.endsWith("agentpay.json") ? candidate : new URL("/.well-known/agentpay.json", candidate.origin);
  const response = await fetcher(manifestUrl, {
    headers: { Accept: "application/json" }
  });
  if (!response.ok) {
    throw new Error(`Merchant does not publish AgentPay discovery metadata (${response.status})`);
  }
  return manifestSchema.parse(await response.json());
}
async function discoverAgentPayCatalog(source, search = {}, fetcher = fetch) {
  const manifest = typeof source === "string" ? await discoverAgentPayMerchant(source, fetcher) : source;
  if (!manifest.catalog_endpoint) {
    throw new Error(`${manifest.merchant.name} does not publish an AgentPay catalog endpoint`);
  }
  const url = new URL(manifest.catalog_endpoint);
  if (search.q) url.searchParams.set("q", search.q);
  if (search.category) url.searchParams.set("category", search.category);
  if (search.productId) url.searchParams.set("product_id", search.productId);
  if (typeof search.maxPriceCents === "number") url.searchParams.set("max_price_cents", String(search.maxPriceCents));
  if (typeof search.limit === "number") url.searchParams.set("limit", String(search.limit));
  const response = await fetcher(url, { headers: { Accept: "application/json" } });
  if (!response.ok) {
    throw new Error(`Merchant catalog is unavailable (${response.status})`);
  }
  const catalog = catalogSchema.parse(await response.json());
  if (catalog.merchant.id !== manifest.merchant.id) {
    throw new Error("Merchant manifest and catalog identify different merchants");
  }
  return catalog;
}
function parseCatalogQuery(url) {
  var _a, _b, _c;
  const q = ((_a = url.searchParams.get("q")) == null ? void 0 : _a.trim()) || null;
  const category = ((_b = url.searchParams.get("category")) == null ? void 0 : _b.trim().toLowerCase()) || null;
  const productId = ((_c = url.searchParams.get("product_id")) == null ? void 0 : _c.trim()) || null;
  const rawMax = Number(url.searchParams.get("max_price_cents"));
  const rawLimit = Number(url.searchParams.get("limit"));
  return {
    q,
    category,
    product_id: productId,
    max_price_cents: Number.isInteger(rawMax) && rawMax > 0 ? rawMax : null,
    limit: Number.isInteger(rawLimit) && rawLimit > 0 ? Math.min(rawLimit, MAX_CATALOG_LIMIT) : DEFAULT_CATALOG_LIMIT
  };
}
function filterCatalogProducts(products, query) {
  var _a;
  const tokens = ((_a = query.q) != null ? _a : "").toLowerCase().split(/\s+/).filter(Boolean);
  const matches = products.filter((product) => {
    var _a2, _b, _c;
    if (query.product_id && product.product_id !== query.product_id) return false;
    if (query.category && product.category.toLowerCase() !== query.category) return false;
    if (query.max_price_cents !== null && product.price_cents > query.max_price_cents) return false;
    if (tokens.length === 0) return true;
    const haystack = [
      product.product_id,
      product.name,
      (_a2 = product.description) != null ? _a2 : "",
      (_b = product.sku) != null ? _b : "",
      (_c = product.brand) != null ? _c : "",
      product.category
    ].join(" ").toLowerCase();
    return tokens.every((token) => haystack.includes(token));
  });
  const ranked = [...matches].sort((a, b) => {
    const stockA = a.availability === "out_of_stock" ? 1 : 0;
    const stockB = b.availability === "out_of_stock" ? 1 : 0;
    return stockA - stockB;
  });
  return { total: matches.length, products: ranked.slice(0, query.limit) };
}
function createAgentPayCatalogHandler(config) {
  return async function catalog(request) {
    var _a;
    const query = parseCatalogQuery(new URL(request.url));
    const all = (await config.products()).map((product) => {
      var _a2;
      return __spreadProps(__spreadValues({}, product), {
        currency: ((_a2 = product.currency) != null ? _a2 : config.currency).toUpperCase()
      });
    });
    const { total, products } = filterCatalogProducts(all, query);
    const body = {
      protocol: "agentpay-catalog/1.0",
      merchant: { id: config.merchantId, name: config.merchantName },
      currency: config.currency.toUpperCase(),
      categories: config.categories ? uniqueSlugs(config.categories) : uniqueSlugs(all.map((p) => p.category)),
      query,
      total,
      products
    };
    return Response.json(body, {
      headers: {
        "access-control-allow-origin": "*",
        "cache-control": `public, max-age=${(_a = config.maxAgeSeconds) != null ? _a : 60}`
      }
    });
  };
}
function deliveryWindow(input) {
  const earliest = addBusinessDays(input.from, input.minBusinessDays);
  const latest = addBusinessDays(input.from, Math.max(input.minBusinessDays, input.maxBusinessDays));
  const day = (date) => date.toLocaleDateString("en-US", { timeZone: "UTC", weekday: "short", month: "short", day: "numeric" });
  return {
    earliest: earliest.toISOString().slice(0, 10),
    latest: latest.toISOString().slice(0, 10),
    text: earliest.getTime() === latest.getTime() ? day(earliest) : `${day(earliest)} \u2013 ${day(latest)}`
  };
}
function addBusinessDays(from, days) {
  const date = new Date(Date.UTC(from.getUTCFullYear(), from.getUTCMonth(), from.getUTCDate()));
  let remaining = Math.max(0, Math.round(days));
  while (remaining > 0) {
    date.setUTCDate(date.getUTCDate() + 1);
    const weekday = date.getUTCDay();
    if (weekday !== 0 && weekday !== 6) remaining -= 1;
  }
  return date;
}
function uniqueSlugs(values) {
  return Array.from(new Set(values.map((value) => value.trim().toLowerCase()).filter(Boolean))).sort();
}
function signAgentPayRequest(input) {
  var _a, _b;
  const url = new URL(input.url);
  const timestamp = ((_a = input.now) != null ? _a : /* @__PURE__ */ new Date()).toISOString();
  const nonce = (_b = input.nonce) != null ? _b : crypto.randomUUID();
  const signature = signText(
    input.privateKey,
    agentSigningMessage({
      method: input.method,
      path: url.pathname,
      body: input.body,
      timestamp,
      nonce
    })
  );
  return new Headers({
    "content-type": "application/json",
    "x-agent-id": input.agentId,
    "x-timestamp": timestamp,
    "x-nonce": nonce,
    "x-signature": signature
  });
}
function createAgentPayCheckoutHandler(config) {
  return async function checkout(request) {
    var _a, _b, _c, _d, _e;
    const fetcher = (_a = config.fetcher) != null ? _a : fetch;
    const now = (_c = (_b = config.now) == null ? void 0 : _b.call(config)) != null ? _c : /* @__PURE__ */ new Date();
    const rawBody = await request.text();
    const agentId = request.headers.get("x-agent-id");
    const timestamp = request.headers.get("x-timestamp");
    const nonce = request.headers.get("x-nonce");
    const signature = request.headers.get("x-signature");
    const invalidSignature = () => Response.json(
      {
        decision: "refused",
        reason_code: "AGENT_SIGNATURE_INVALID",
        checks: {
          agent_signature: false,
          mandate_signature: false,
          registry_status: false,
          policy: false
        }
      },
      { status: 401 }
    );
    if (!agentId || !timestamp || !nonce || !signature) {
      return invalidSignature();
    }
    const signedAt = new Date(timestamp);
    if (!Number.isFinite(signedAt.valueOf()) || Math.abs(now.valueOf() - signedAt.valueOf()) > 6e4) {
      return invalidSignature();
    }
    const agentResponse = await fetcher(
      new URL(`/api/registry/agents/${encodeURIComponent(agentId)}`, config.registryUrl),
      { headers: { Accept: "application/json" } }
    );
    if (!agentResponse.ok) {
      return invalidSignature();
    }
    const agent = z.object({ id: z.string(), public_key: z.string() }).parse(await agentResponse.json());
    const validAgentSignature = verifyText(
      agent.public_key,
      agentSigningMessage({
        method: request.method,
        path: new URL(request.url).pathname,
        body: rawBody,
        timestamp,
        nonce
      }),
      signature
    );
    if (!validAgentSignature) {
      return invalidSignature();
    }
    const nonceResponse = await fetcher(new URL("/api/registry/nonces", config.registryUrl), {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ agent_id: agentId, nonce, timestamp })
    });
    if (!nonceResponse.ok) {
      return invalidSignature();
    }
    const parsedBody = checkoutBodySchema.safeParse(JSON.parse(rawBody));
    if (!parsedBody.success || parsedBody.data.merchant_id !== config.merchantId) {
      return Response.json({ error: "Invalid checkout payload" }, { status: 400 });
    }
    const product = await config.resolveProduct(parsedBody.data.product_id);
    if (!product || product.merchant_id !== config.merchantId) {
      return Response.json({ error: "Product not found" }, { status: 404 });
    }
    const mandateResponse = await fetcher(
      new URL(`/api/registry/mandates/${parsedBody.data.mandate_id}`, config.registryUrl),
      { headers: { Accept: "application/json" }, cache: "no-store" }
    );
    const mandate = mandateResponse.ok ? z.custom().parse(await mandateResponse.json()) : null;
    const registryKeyResponse = await fetcher(new URL("/api/registry/keys", config.registryUrl), {
      headers: { Accept: "application/json" },
      cache: "force-cache"
    });
    const registryKey = registryKeyResponse.ok ? z.object({ algorithm: z.literal("Ed25519"), public_key: z.string() }).parse(await registryKeyResponse.json()) : null;
    const mandateArtifact = mandate ? __spreadValues({
      mandate_id: mandate.mandate_id,
      type: mandate.type,
      issuer: mandate.issuer,
      agent: mandate.agent,
      scope: mandate.scope,
      limits: mandate.limits,
      validity: mandate.validity,
      payment: mandate.payment
    }, mandate.authorization ? { authorization: mandate.authorization } : {}) : null;
    const mandateSignatureValid = Boolean(
      mandateArtifact && (mandate == null ? void 0 : mandate.server_sig) && registryKey && mandate.agent.agent_id === agentId && mandate.agent.public_key === agent.public_key && verifyText(registryKey.public_key, canonicalJson(mandateArtifact), mandate.server_sig)
    );
    let fulfillment;
    if (config.resolveFulfillment) {
      const address = parsedBody.data.shipping_address;
      if (!address) {
        return Response.json(
          {
            decision: "refused",
            reason_code: "SHIPPING_ADDRESS_UNSUPPORTED",
            product,
            checks: { agent_signature: true, mandate_signature: false, registry_status: false, policy: false }
          },
          { status: 200 }
        );
      }
      const quoted = await config.resolveFulfillment({
        product,
        address,
        address_source: (_d = parsedBody.data.shipping_address_source) != null ? _d : "registered",
        now
      });
      if (!quoted) {
        return Response.json(
          {
            decision: "refused",
            reason_code: "SHIPPING_ADDRESS_UNSUPPORTED",
            product,
            checks: { agent_signature: true, mandate_signature: false, registry_status: false, policy: false }
          },
          { status: 200 }
        );
      }
      fulfillment = quoted;
    }
    const shippingCents = (_e = fulfillment == null ? void 0 : fulfillment.shipping_cents) != null ? _e : 0;
    const charge = {
      subtotal_cents: product.price_cents,
      shipping_cents: shippingCents,
      total_cents: product.price_cents + shippingCents,
      currency: product.currency
    };
    const cart = {
      mandate_id: parsedBody.data.mandate_id,
      merchant_id: config.merchantId,
      product_id: product.id,
      category: product.category,
      amount_cents: charge.total_cents,
      currency: product.currency,
      exception_id: parsedBody.data.exception_id
    };
    const policy = mandateSignatureValid ? evaluatePolicy(mandate, cart, now) : { decision: "refused", reason_code: "MANDATE_SIGNATURE_INVALID" };
    return Response.json(__spreadProps(__spreadValues(__spreadProps(__spreadValues({}, policy), {
      product,
      charge
    }), fulfillment ? { fulfillment } : {}), {
      checks: {
        agent_signature: true,
        mandate_signature: mandateSignatureValid,
        registry_status: (mandate == null ? void 0 : mandate.status) === "active",
        policy: policy.decision === "approved"
      }
    }));
  };
}
export {
  DEFAULT_CATALOG_LIMIT,
  MAX_CATALOG_LIMIT,
  agentSigningMessage,
  canonicalJson,
  createAgentPayCatalogHandler,
  createAgentPayCheckoutHandler,
  deliveryWindow,
  discoverAgentPayCatalog,
  discoverAgentPayMerchant,
  evaluatePolicy,
  filterCatalogProducts,
  generateEd25519KeyPair,
  merchantManifest,
  parseCatalogQuery,
  shippingAddressSchema,
  signAgentPayRequest,
  signCanonical,
  signText,
  verifyText
};
