type MandateStatus = "draft" | "active" | "revoked" | "expired";
type MandateScope = {
    merchants: string[];
    categories: string[];
};
type MandateLimits = {
    per_purchase_cents: number;
    cumulative_cents: number;
    max_uses: number;
    period: "month";
    currency: string;
};
type MandateValidity = {
    not_before: string;
    expires_at: string;
};
type RegistryMandate = {
    mandate_id: string;
    type: "intent";
    issuer: {
        user_id: string;
    };
    agent: {
        agent_id: string;
        public_key: string;
    };
    scope: MandateScope;
    limits: MandateLimits;
    validity: MandateValidity;
    payment: {
        vault_card_id: string;
    };
    authorization: {
        credential_id: string;
        mandate_hash: string;
        signed_at: string;
    } | null;
    server_sig: string | null;
    status: MandateStatus;
    usage: {
        approved_uses: number;
        cumulative_cents: number;
    };
};
type CheckoutCart = {
    mandate_id: string;
    merchant_id: string;
    product_id: string;
    category: string;
    amount_cents: number;
    currency: string;
    exception_id?: string;
};
type PolicyReason = "AGENT_SIGNATURE_INVALID" | "MANDATE_SIGNATURE_INVALID" | "MANDATE_NOT_FOUND" | "MANDATE_REVOKED" | "MANDATE_EXPIRED" | "MERCHANT_NOT_IN_SCOPE" | "CATEGORY_NOT_IN_SCOPE" | "CURRENCY_MISMATCH" | "USES_EXCEEDED" | "CUMULATIVE_EXCEEDED" | "AMOUNT_EXCEEDS_LIMIT";
type PolicyDecision = {
    decision: "approved";
    reason_code: null;
} | {
    decision: "refused";
    reason_code: PolicyReason;
} | {
    decision: "escalated";
    reason_code: "AMOUNT_EXCEEDS_LIMIT";
};
type AgentPayCapability = "intent-mandates" | "live-revocation" | "mock-payment" | "catalog-search";
type AgentPayMerchantManifest = {
    protocol: "agentpay/1.0";
    merchant: {
        id: string;
        name: string;
    };
    checkout_endpoint: string;
    registry_url: string;
    /** Known values are listed in AgentPayCapability; unknown values are ignored. */
    capabilities: string[];
    /** Store-owned catalog endpoint. Optional: merchants on SDK 0.1.0 omit it. */
    catalog_endpoint?: string;
    /** Exact category slugs a mandate may be scoped to at this merchant. */
    categories?: string[];
    /** Currency every product is quoted in and every mandate must be denominated in. */
    currency?: string;
    /** Template containing `{id}`, resolved against the store origin, for a product page. */
    product_url_template?: string;
    documentation_url?: string;
};
type AgentPayCatalogProduct = {
    product_id: string;
    name: string;
    category: string;
    price_cents: number;
    currency: string;
    description?: string;
    sku?: string;
    brand?: string;
    availability?: "in_stock" | "out_of_stock";
    url?: string;
};
type AgentPayCatalogQuery = {
    q: string | null;
    category: string | null;
    product_id: string | null;
    max_price_cents: number | null;
    limit: number;
};
type AgentPayMerchantCatalog = {
    protocol: "agentpay-catalog/1.0";
    merchant: {
        id: string;
        name: string;
    };
    currency: string;
    categories: string[];
    query: AgentPayCatalogQuery;
    /** Matches before `limit` was applied. */
    total: number;
    products: AgentPayCatalogProduct[];
};

declare function agentSigningMessage(input: {
    method: string;
    path: string;
    body: string;
    timestamp: string;
    nonce: string;
}): string;
declare function generateEd25519KeyPair(): {
    privateKey: string;
    publicKey: string;
};
declare function signText(privateKeyPem: string, value: string): string;
declare function verifyText(publicKeyPem: string, value: string, signature: string): boolean;
declare function signCanonical(privateKeyPem: string, value: unknown): string;

declare function canonicalJson(value: unknown): string;

declare function evaluatePolicy(mandate: RegistryMandate | null, cart: CheckoutCart, now?: Date): PolicyDecision;

type MerchantProduct = {
    id: string;
    merchant_id: string;
    name: string;
    category: string;
    price_cents: number;
    currency: string;
};
type MerchantCheckoutResult = PolicyDecision & {
    product?: MerchantProduct;
    checks: {
        agent_signature: boolean;
        mandate_signature: boolean;
        registry_status: boolean;
        policy: boolean;
    };
};
type FetchLike = typeof fetch;
declare const DEFAULT_CATALOG_LIMIT = 10;
declare const MAX_CATALOG_LIMIT = 50;
declare function merchantManifest(input: {
    origin: string;
    merchantId: string;
    merchantName: string;
    checkoutPath?: string;
    registryUrl?: string;
    /** Path of the catalog route built with createAgentPayCatalogHandler. */
    catalogPath?: string;
    /** Exact category slugs a buyer may scope a mandate to. Keep them coarse and stable. */
    categories?: string[];
    /** The currency every product is quoted in. Mandates must match it exactly. */
    currency?: string;
    /** Path template containing `{id}` for a product page, e.g. "/product/{id}". */
    productUrlTemplate?: string;
    documentationUrl?: string;
}): AgentPayMerchantManifest;
declare function discoverAgentPayMerchant(merchantUrl: string, fetcher?: FetchLike): Promise<AgentPayMerchantManifest>;
type CatalogSearch = {
    q?: string;
    category?: string;
    productId?: string;
    maxPriceCents?: number;
    limit?: number;
};
/**
 * Reads a store's catalog through the endpoint its manifest advertises. The
 * store does the filtering, so an agent asks one question and receives exact
 * product ids, categories and prices instead of scraping a rendered page.
 */
declare function discoverAgentPayCatalog(source: string | AgentPayMerchantManifest, search?: CatalogSearch, fetcher?: FetchLike): Promise<AgentPayMerchantCatalog>;
declare function parseCatalogQuery(url: URL): AgentPayCatalogQuery;
/**
 * Deterministic catalog filtering shared by every store on the SDK, so an agent
 * gets the same semantics everywhere: every search token must appear in the
 * product text, category and product id are exact, and in-stock items sort
 * first. Returns the matches before and after `limit`.
 */
declare function filterCatalogProducts(products: AgentPayCatalogProduct[], query: AgentPayCatalogQuery): {
    total: number;
    products: AgentPayCatalogProduct[];
};
/**
 * Builds the catalog route a manifest advertises as `catalog_endpoint`. The
 * store keeps ownership of its products; the handler only makes them
 * addressable by exact id, category and price so an agent can size a mandate
 * and purchase without guessing.
 */
declare function createAgentPayCatalogHandler(config: {
    merchantId: string;
    merchantName: string;
    currency: string;
    /** Defaults to the distinct categories of the products returned. */
    categories?: string[];
    products: () => Promise<AgentPayCatalogProduct[]> | AgentPayCatalogProduct[];
    /** Cache-control max-age in seconds. Defaults to 60. */
    maxAgeSeconds?: number;
}): (request: Request) => Promise<Response>;
declare function signAgentPayRequest(input: {
    agentId: string;
    privateKey: string;
    method: string;
    url: string;
    body: string;
    now?: Date;
    nonce?: string;
}): Headers;
declare function createAgentPayCheckoutHandler(config: {
    merchantId: string;
    registryUrl: string;
    resolveProduct: (productId: string) => Promise<MerchantProduct | null>;
    fetcher?: FetchLike;
    now?: () => Date;
}): (request: Request) => Promise<Response>;

export { type AgentPayCapability, type AgentPayCatalogProduct, type AgentPayCatalogQuery, type AgentPayMerchantCatalog, type AgentPayMerchantManifest, type CatalogSearch, type CheckoutCart, DEFAULT_CATALOG_LIMIT, MAX_CATALOG_LIMIT, type MandateStatus, type MerchantCheckoutResult, type MerchantProduct, type PolicyDecision, type PolicyReason, type RegistryMandate, agentSigningMessage, canonicalJson, createAgentPayCatalogHandler, createAgentPayCheckoutHandler, discoverAgentPayCatalog, discoverAgentPayMerchant, evaluatePolicy, filterCatalogProducts, generateEd25519KeyPair, merchantManifest, parseCatalogQuery, signAgentPayRequest, signCanonical, signText, verifyText };
