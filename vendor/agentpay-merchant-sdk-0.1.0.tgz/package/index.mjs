var __defProp = Object.defineProperty;
var __defProps = Object.defineProperties;
var __getOwnPropDescs = Object.getOwnPropertyDescriptors;
var __getOwnPropSymbols = Object.getOwnPropertySymbols;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __propIsEnum = Object.prototype.propertyIsEnumerable;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __spreadValues = (a, b) => {
  for (var prop in b || (b = {}))
    if (__hasOwnProp.call(b, prop))
      __defNormalProp(a, prop, b[prop]);
  if (__getOwnPropSymbols)
    for (var prop of __getOwnPropSymbols(b)) {
      if (__propIsEnum.call(b, prop))
        __defNormalProp(a, prop, b[prop]);
    }
  return a;
};
var __spreadProps = (a, b) => __defProps(a, __getOwnPropDescs(b));

// sdk/index.ts
import { z } from "zod";

// lib/crypto.ts
import {
  createCipheriv,
  createDecipheriv,
  createHash,
  createPrivateKey,
  createPublicKey,
  generateKeyPairSync,
  randomBytes,
  sign,
  verify
} from "crypto";

// lib/canonical-json.ts
function sortValue(value) {
  if (Array.isArray(value)) {
    return value.map(sortValue);
  }
  if (value && typeof value === "object") {
    return Object.fromEntries(
      Object.entries(value).sort(([left], [right]) => left.localeCompare(right)).map(([key, nested]) => [key, sortValue(nested)])
    );
  }
  return value;
}
function canonicalJson(value) {
  return JSON.stringify(sortValue(value));
}

// lib/crypto.ts
function sha256Base64Url(input) {
  return createHash("sha256").update(input).digest("base64url");
}
function bodyHash(body) {
  return sha256Base64Url(body);
}
function agentSigningMessage(input) {
  return [
    input.method.toUpperCase(),
    input.path,
    bodyHash(input.body),
    input.timestamp,
    input.nonce
  ].join("|");
}
function generateEd25519KeyPair() {
  const { privateKey, publicKey } = generateKeyPairSync("ed25519");
  return {
    privateKey: privateKey.export({ type: "pkcs8", format: "pem" }).toString(),
    publicKey: publicKey.export({ type: "spki", format: "pem" }).toString()
  };
}
function signText(privateKeyPem, value) {
  return sign(null, Buffer.from(value), createPrivateKey(privateKeyPem)).toString("base64url");
}
function verifyText(publicKeyPem, value, signature) {
  try {
    return verify(
      null,
      Buffer.from(value),
      createPublicKey(publicKeyPem),
      Buffer.from(signature, "base64url")
    );
  } catch (e) {
    return false;
  }
}
function signCanonical(privateKeyPem, value) {
  return signText(privateKeyPem, canonicalJson(value));
}

// lib/agentpay-policy.ts
function evaluatePolicy(mandate, cart, now = /* @__PURE__ */ new Date()) {
  if (!mandate) {
    return { decision: "refused", reason_code: "MANDATE_NOT_FOUND" };
  }
  if (mandate.status === "revoked") {
    return { decision: "refused", reason_code: "MANDATE_REVOKED" };
  }
  if (mandate.status !== "active" || now < new Date(mandate.validity.not_before) || now > new Date(mandate.validity.expires_at)) {
    return { decision: "refused", reason_code: "MANDATE_EXPIRED" };
  }
  if (!mandate.scope.merchants.includes(cart.merchant_id)) {
    return { decision: "refused", reason_code: "MERCHANT_NOT_IN_SCOPE" };
  }
  if (!mandate.scope.categories.includes(cart.category)) {
    return { decision: "refused", reason_code: "CATEGORY_NOT_IN_SCOPE" };
  }
  if (cart.currency !== mandate.limits.currency) {
    return { decision: "refused", reason_code: "CURRENCY_MISMATCH" };
  }
  if (mandate.usage.approved_uses >= mandate.limits.max_uses) {
    return { decision: "refused", reason_code: "USES_EXCEEDED" };
  }
  if (mandate.usage.cumulative_cents + cart.amount_cents > mandate.limits.cumulative_cents) {
    return { decision: "refused", reason_code: "CUMULATIVE_EXCEEDED" };
  }
  if (cart.amount_cents > mandate.limits.per_purchase_cents && !cart.exception_id) {
    return { decision: "escalated", reason_code: "AMOUNT_EXCEEDS_LIMIT" };
  }
  return { decision: "approved", reason_code: null };
}

// sdk/index.ts
var manifestSchema = z.object({
  protocol: z.literal("agentpay/1.0"),
  merchant: z.object({ id: z.string().min(1), name: z.string().min(1) }),
  checkout_endpoint: z.url(),
  registry_url: z.url(),
  capabilities: z.tuple([
    z.literal("intent-mandates"),
    z.literal("live-revocation"),
    z.literal("mock-payment")
  ])
});
var checkoutBodySchema = z.object({
  mandate_id: z.uuid(),
  merchant_id: z.string().min(1),
  product_id: z.string().min(1),
  exception_id: z.uuid().optional()
});
function merchantManifest(input) {
  var _a;
  const origin = new URL(input.origin).origin;
  return {
    protocol: "agentpay/1.0",
    merchant: { id: input.merchantId, name: input.merchantName },
    checkout_endpoint: new URL((_a = input.checkoutPath) != null ? _a : "/api/store/checkout", origin).toString(),
    registry_url: input.registryUrl ? new URL(input.registryUrl).toString() : origin,
    capabilities: ["intent-mandates", "live-revocation", "mock-payment"]
  };
}
async function discoverAgentPayMerchant(merchantUrl, fetcher = fetch) {
  const candidate = new URL(merchantUrl);
  const manifestUrl = candidate.pathname.endsWith("agentpay.json") ? candidate : new URL("/.well-known/agentpay.json", candidate.origin);
  const response = await fetcher(manifestUrl, {
    headers: { Accept: "application/json" }
  });
  if (!response.ok) {
    throw new Error(`Merchant does not publish AgentPay discovery metadata (${response.status})`);
  }
  return manifestSchema.parse(await response.json());
}
function signAgentPayRequest(input) {
  var _a, _b;
  const url = new URL(input.url);
  const timestamp = ((_a = input.now) != null ? _a : /* @__PURE__ */ new Date()).toISOString();
  const nonce = (_b = input.nonce) != null ? _b : crypto.randomUUID();
  const signature = signText(
    input.privateKey,
    agentSigningMessage({
      method: input.method,
      path: url.pathname,
      body: input.body,
      timestamp,
      nonce
    })
  );
  return new Headers({
    "content-type": "application/json",
    "x-agent-id": input.agentId,
    "x-timestamp": timestamp,
    "x-nonce": nonce,
    "x-signature": signature
  });
}
function createAgentPayCheckoutHandler(config) {
  return async function checkout(request) {
    var _a, _b, _c;
    const fetcher = (_a = config.fetcher) != null ? _a : fetch;
    const now = (_c = (_b = config.now) == null ? void 0 : _b.call(config)) != null ? _c : /* @__PURE__ */ new Date();
    const rawBody = await request.text();
    const agentId = request.headers.get("x-agent-id");
    const timestamp = request.headers.get("x-timestamp");
    const nonce = request.headers.get("x-nonce");
    const signature = request.headers.get("x-signature");
    const invalidSignature = () => Response.json(
      {
        decision: "refused",
        reason_code: "AGENT_SIGNATURE_INVALID",
        checks: {
          agent_signature: false,
          mandate_signature: false,
          registry_status: false,
          policy: false
        }
      },
      { status: 401 }
    );
    if (!agentId || !timestamp || !nonce || !signature) {
      return invalidSignature();
    }
    const signedAt = new Date(timestamp);
    if (!Number.isFinite(signedAt.valueOf()) || Math.abs(now.valueOf() - signedAt.valueOf()) > 6e4) {
      return invalidSignature();
    }
    const agentResponse = await fetcher(
      new URL(`/api/registry/agents/${encodeURIComponent(agentId)}`, config.registryUrl),
      { headers: { Accept: "application/json" } }
    );
    if (!agentResponse.ok) {
      return invalidSignature();
    }
    const agent = z.object({ id: z.string(), public_key: z.string() }).parse(await agentResponse.json());
    const validAgentSignature = verifyText(
      agent.public_key,
      agentSigningMessage({
        method: request.method,
        path: new URL(request.url).pathname,
        body: rawBody,
        timestamp,
        nonce
      }),
      signature
    );
    if (!validAgentSignature) {
      return invalidSignature();
    }
    const nonceResponse = await fetcher(new URL("/api/registry/nonces", config.registryUrl), {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ agent_id: agentId, nonce, timestamp })
    });
    if (!nonceResponse.ok) {
      return invalidSignature();
    }
    const parsedBody = checkoutBodySchema.safeParse(JSON.parse(rawBody));
    if (!parsedBody.success || parsedBody.data.merchant_id !== config.merchantId) {
      return Response.json({ error: "Invalid checkout payload" }, { status: 400 });
    }
    const product = await config.resolveProduct(parsedBody.data.product_id);
    if (!product || product.merchant_id !== config.merchantId) {
      return Response.json({ error: "Product not found" }, { status: 404 });
    }
    const mandateResponse = await fetcher(
      new URL(`/api/registry/mandates/${parsedBody.data.mandate_id}`, config.registryUrl),
      { headers: { Accept: "application/json" }, cache: "no-store" }
    );
    const mandate = mandateResponse.ok ? z.custom().parse(await mandateResponse.json()) : null;
    const registryKeyResponse = await fetcher(new URL("/api/registry/keys", config.registryUrl), {
      headers: { Accept: "application/json" },
      cache: "force-cache"
    });
    const registryKey = registryKeyResponse.ok ? z.object({ algorithm: z.literal("Ed25519"), public_key: z.string() }).parse(await registryKeyResponse.json()) : null;
    const mandateArtifact = mandate ? __spreadValues({
      mandate_id: mandate.mandate_id,
      type: mandate.type,
      issuer: mandate.issuer,
      agent: mandate.agent,
      scope: mandate.scope,
      limits: mandate.limits,
      validity: mandate.validity,
      payment: mandate.payment
    }, mandate.authorization ? { authorization: mandate.authorization } : {}) : null;
    const mandateSignatureValid = Boolean(
      mandateArtifact && (mandate == null ? void 0 : mandate.server_sig) && registryKey && mandate.agent.agent_id === agentId && mandate.agent.public_key === agent.public_key && verifyText(registryKey.public_key, canonicalJson(mandateArtifact), mandate.server_sig)
    );
    const cart = {
      mandate_id: parsedBody.data.mandate_id,
      merchant_id: config.merchantId,
      product_id: product.id,
      category: product.category,
      amount_cents: product.price_cents,
      currency: product.currency,
      exception_id: parsedBody.data.exception_id
    };
    const policy = mandateSignatureValid ? evaluatePolicy(mandate, cart, now) : { decision: "refused", reason_code: "MANDATE_SIGNATURE_INVALID" };
    return Response.json(__spreadProps(__spreadValues({}, policy), {
      product,
      checks: {
        agent_signature: true,
        mandate_signature: mandateSignatureValid,
        registry_status: (mandate == null ? void 0 : mandate.status) === "active",
        policy: policy.decision === "approved"
      }
    }));
  };
}
export {
  agentSigningMessage,
  canonicalJson,
  createAgentPayCheckoutHandler,
  discoverAgentPayMerchant,
  generateEd25519KeyPair,
  merchantManifest,
  signAgentPayRequest,
  signCanonical,
  signText,
  verifyText
};
