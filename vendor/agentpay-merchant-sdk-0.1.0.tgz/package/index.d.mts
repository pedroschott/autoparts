type MandateStatus = "draft" | "active" | "revoked" | "expired";
type MandateScope = {
    merchants: string[];
    categories: string[];
};
type MandateLimits = {
    per_purchase_cents: number;
    cumulative_cents: number;
    max_uses: number;
    period: "month";
    currency: string;
};
type MandateValidity = {
    not_before: string;
    expires_at: string;
};
type RegistryMandate = {
    mandate_id: string;
    type: "intent";
    issuer: {
        user_id: string;
    };
    agent: {
        agent_id: string;
        public_key: string;
    };
    scope: MandateScope;
    limits: MandateLimits;
    validity: MandateValidity;
    payment: {
        vault_card_id: string;
    };
    authorization: {
        credential_id: string;
        mandate_hash: string;
        signed_at: string;
    } | null;
    server_sig: string | null;
    status: MandateStatus;
    usage: {
        approved_uses: number;
        cumulative_cents: number;
    };
};
type CheckoutCart = {
    mandate_id: string;
    merchant_id: string;
    product_id: string;
    category: string;
    amount_cents: number;
    currency: string;
    exception_id?: string;
};
type PolicyReason = "AGENT_SIGNATURE_INVALID" | "MANDATE_SIGNATURE_INVALID" | "MANDATE_NOT_FOUND" | "MANDATE_REVOKED" | "MANDATE_EXPIRED" | "MERCHANT_NOT_IN_SCOPE" | "CATEGORY_NOT_IN_SCOPE" | "CURRENCY_MISMATCH" | "USES_EXCEEDED" | "CUMULATIVE_EXCEEDED" | "AMOUNT_EXCEEDS_LIMIT";
type PolicyDecision = {
    decision: "approved";
    reason_code: null;
} | {
    decision: "refused";
    reason_code: PolicyReason;
} | {
    decision: "escalated";
    reason_code: "AMOUNT_EXCEEDS_LIMIT";
};
type AgentPayMerchantManifest = {
    protocol: "agentpay/1.0";
    merchant: {
        id: string;
        name: string;
    };
    checkout_endpoint: string;
    registry_url: string;
    capabilities: ["intent-mandates", "live-revocation", "mock-payment"];
};

declare function agentSigningMessage(input: {
    method: string;
    path: string;
    body: string;
    timestamp: string;
    nonce: string;
}): string;
declare function generateEd25519KeyPair(): {
    privateKey: string;
    publicKey: string;
};
declare function signText(privateKeyPem: string, value: string): string;
declare function verifyText(publicKeyPem: string, value: string, signature: string): boolean;
declare function signCanonical(privateKeyPem: string, value: unknown): string;

declare function canonicalJson(value: unknown): string;

type MerchantProduct = {
    id: string;
    merchant_id: string;
    name: string;
    category: string;
    price_cents: number;
    currency: string;
};
type MerchantCheckoutResult = PolicyDecision & {
    product?: MerchantProduct;
    checks: {
        agent_signature: boolean;
        mandate_signature: boolean;
        registry_status: boolean;
        policy: boolean;
    };
};
type FetchLike = typeof fetch;
declare function merchantManifest(input: {
    origin: string;
    merchantId: string;
    merchantName: string;
    checkoutPath?: string;
    registryUrl?: string;
}): AgentPayMerchantManifest;
declare function discoverAgentPayMerchant(merchantUrl: string, fetcher?: FetchLike): Promise<AgentPayMerchantManifest>;
declare function signAgentPayRequest(input: {
    agentId: string;
    privateKey: string;
    method: string;
    url: string;
    body: string;
    now?: Date;
    nonce?: string;
}): Headers;
declare function createAgentPayCheckoutHandler(config: {
    merchantId: string;
    registryUrl: string;
    resolveProduct: (productId: string) => Promise<MerchantProduct | null>;
    fetcher?: FetchLike;
    now?: () => Date;
}): (request: Request) => Promise<Response>;

export { type AgentPayMerchantManifest, type CheckoutCart, type MandateStatus, type MerchantCheckoutResult, type MerchantProduct, type PolicyDecision, type PolicyReason, type RegistryMandate, agentSigningMessage, canonicalJson, createAgentPayCheckoutHandler, discoverAgentPayMerchant, generateEd25519KeyPair, merchantManifest, signAgentPayRequest, signCanonical, signText, verifyText };
